/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of blog
 */
export { BlogService } from './lib/blog.service';
export { BlogComponent } from './lib/blog.component';
export { BlogModule } from './lib/blog.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL2Jsb2cvIiwic291cmNlcyI6WyJwdWJsaWMtYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFJQSw0QkFBYyxvQkFBb0IsQ0FBQztBQUNuQyw4QkFBYyxzQkFBc0IsQ0FBQztBQUNyQywyQkFBYyxtQkFBbUIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiAqIFB1YmxpYyBBUEkgU3VyZmFjZSBvZiBibG9nXHJcbiAqL1xyXG5cclxuZXhwb3J0ICogZnJvbSAnLi9saWIvYmxvZy5zZXJ2aWNlJztcclxuZXhwb3J0ICogZnJvbSAnLi9saWIvYmxvZy5jb21wb25lbnQnO1xyXG5leHBvcnQgKiBmcm9tICcuL2xpYi9ibG9nLm1vZHVsZSc7XHJcbiJdfQ==