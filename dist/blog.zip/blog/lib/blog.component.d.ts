import { OnInit } from '@angular/core';
export declare class BlogComponent implements OnInit {
    blogListConfig: any;
    loader: boolean;
    config: any;
    constructor();
    ngOnInit(): void;
}
