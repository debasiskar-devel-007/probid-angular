export declare class AppRoutingModule {
}
